// Mobile Menu Toggle
document.getElementById("menu-btn").addEventListener("click", () => {
    document.getElementById("nav-links").classList.toggle("active");
});

// Course Data Array of Objects
const courses = [
    { title: "HTML5 Semantic Mastery", category: "Frontend", desc: "Build accessible and structured webpages from scratch." },
    { title: "Modern CSS3 & Grid", category: "Frontend", desc: "Design responsive layouts using Flexbox, Grid, and Media Queries." },
    { title: "JavaScript ES6 & DOM", category: "Frontend", desc: "Create dynamic, interactive user interfaces with clean JS." },
    { title: "Node.js & REST APIs", category: "Backend", desc: "Build scalable server-side applications and APIs." },
    { title: "Git & GitHub Workflow", category: "Tools", desc: "Master version control, commits, branches, and GitHub Pages." },
    { title: "Database Fundamentals", category: "Backend", desc: "Understand relational and NoSQL data modeling." }
];

const coursesGrid = document.getElementById("courses-grid");
const courseSearch = document.getElementById("course-search");
const categoryFilter = document.getElementById("category-filter");

function renderCourses() {
    const query = courseSearch.value.toLowerCase();
    const cat = categoryFilter.value;

    const filtered = courses.filter(c =>
        c.title.toLowerCase().includes(query) && (cat === "All" || c.category === cat)
    );

    coursesGrid.innerHTML = filtered.map(c => `
        <div class="course-card">
            <span>${c.category}</span>
            <h3>${c.title}</h3>
            <p>${c.desc}</p>
        </div>
    `).join("");

    document.getElementById("course-count").textContent = filtered.length;
}

courseSearch.addEventListener("input", renderCourses);
categoryFilter.addEventListener("change", renderCourses);
renderCourses();

// Study Goal Tracker (Add, Toggle Complete, Delete)
let goals = [
    { id: 1, text: "Deploy Week 6 Capstone on GitHub Pages", completed: false },
    { id: 2, text: "Complete all InternNova assignments", completed: true }
];

const goalList = document.getElementById("goal-list");
const goalInput = document.getElementById("goal-input");

function renderGoals() {
    goalList.innerHTML = "";
    goals.forEach(g => {
        const li = document.createElement("li");
        li.className = `goal-item ${g.completed ? "done" : ""}`;
        li.innerHTML = `
            <span>${g.text}</span>
            <div class="goal-actions">
                <button class="btn-toggle" onclick="toggleGoal(${g.id})">${g.completed ? "Undo" : "Done"}</button>
                <button class="btn-del" onclick="deleteGoal(${g.id})">Delete</button>
            </div>
        `;
        goalList.appendChild(li);
    });
    document.getElementById("goal-count").textContent = goals.length;
}

document.getElementById("goal-form").addEventListener("submit", e => {
    e.preventDefault();
    const val = goalInput.value.trim();
    if (!val) return;
    goals.push({ id: Date.now(), text: val, completed: false });
    goalInput.value = "";
    renderGoals();
});

function toggleGoal(id) {
    goals = goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g);
    renderGoals();
}

function deleteGoal(id) {
    goals = goals.filter(g => g.id !== id);
    renderGoals();
}
renderGoals();

// Contact Form Validation
document.getElementById("contact-form").addEventListener("submit", e => {
    e.preventDefault();
    const name = document.getElementById("user-name").value.trim();
    const email = document.getElementById("user-email").value.trim();
    const feedback = document.getElementById("form-feedback");

    if (name.length < 3 || !email.includes("@")) {
        feedback.textContent = "Please enter a valid name and email address.";
        feedback.style.color = "#ef4444";
        return;
    }

    feedback.textContent = `Thank you, ${name}! Your message has been received.`;
    feedback.style.color = "#22c55e";
    e.target.reset();
});